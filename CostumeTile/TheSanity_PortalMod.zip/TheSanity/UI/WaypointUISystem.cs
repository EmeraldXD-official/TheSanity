using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ModLoader;
using Terraria.UI;

namespace TheSanity.UI
{
    public class WaypointUISystem : ModSystem
    {
        private static UserInterface userInterface;
        private static WaypointUIState state;
        private static bool visible;

        public override void Load()
        {
            if (Main.dedServ) return;

            state = new WaypointUIState();
            state.Activate();
            userInterface = new UserInterface();
        }

        public override void Unload()
        {
            userInterface = null;
            state = null;
        }

        public static void OpenForPortal(Point16 baseOrigin)
        {
            if (Main.dedServ || state == null) return;

            state.SetPortal(baseOrigin);
            userInterface.SetState(state);
            visible = true;

            Main.LocalPlayer.mouseInterface = true;
        }

        public static void CloseUI()
        {
            userInterface?.SetState(null);
            visible = false;
        }

        public override void UpdateUI(GameTime gameTime)
        {
            if (visible)
                userInterface?.Update(gameTime);
        }

        public override void ModifyInterfaceLayers(List<GameInterfaceLayer> layers)
        {
            if (!visible) return;

            int mouseTextIndex = layers.FindIndex(layer => layer.Name.Equals("Vanilla: Mouse Text"));
            if (mouseTextIndex == -1) return;

            layers.Insert(mouseTextIndex, new LegacyGameInterfaceLayer(
                "TheSanity: Waypoint UI",
                delegate
                {
                    userInterface?.Draw(Main.spriteBatch, new GameTime());
                    return true;
                },
                InterfaceScaleType.UI));
        }
    }
}
