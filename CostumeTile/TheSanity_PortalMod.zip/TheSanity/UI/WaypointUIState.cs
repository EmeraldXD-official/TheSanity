using System.Linq;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.GameContent.UI.Elements;
using Terraria.ModLoader;
using Terraria.UI;
using TheSanity.Players;
using TheSanity.Systems;
using TheSanity.TileEntities;

namespace TheSanity.UI
{
    public class WaypointUIState : UIState
    {
        private Point16 currentBaseOrigin;
        private UIPanel mainPanel;
        private UIInputTextField nameField;
        private UIList waypointList;
        private UIText statusText;

        public override void OnInitialize()
        {
            mainPanel = new UIPanel();
            mainPanel.Width.Set(360f, 0f);
            mainPanel.Height.Set(420f, 0f);
            mainPanel.HAlign = 0.5f;
            mainPanel.VAlign = 0.5f;
            mainPanel.BackgroundColor = new Color(35, 20, 45, 230);
            Append(mainPanel);

            var title = new UIText("Waypoint", 0.9f) { HAlign = 0.5f };
            title.Top.Set(10f, 0f);
            mainPanel.Append(title);

            nameField = new UIInputTextField("waypoint")
            {
                Width = { Percent = 1f, Pixels = -20f },
                Height = { Pixels = 34f },
                Top = { Pixels = 44f },
                HAlign = 0.5f
            };
            mainPanel.Append(nameField);

            var saveNameButton = new UIText("[Simpan Nama]", 0.65f)
            {
                HAlign = 0.5f,
                Top = { Pixels = 82f }
            };
            saveNameButton.OnLeftClick += (_, _) => CommitRename();
            saveNameButton.OnMouseOver += (_, _) => saveNameButton.TextColor = Color.Yellow;
            saveNameButton.OnMouseOut += (_, _) => saveNameButton.TextColor = Color.White;
            mainPanel.Append(saveNameButton);

            var listHeader = new UIText("Pilih tujuan estimasi:", 0.8f)
            {
                Top = { Pixels = 112f },
                Left = { Pixels = 10f }
            };
            mainPanel.Append(listHeader);

            waypointList = new UIList
            {
                Width = { Percent = 1f, Pixels = -40f },
                Height = { Pixels = 220f },
                Top = { Pixels = 140f },
                HAlign = 0.5f,
                ListPadding = 4f
            };
            mainPanel.Append(waypointList);

            var scrollbar = new UIScrollbar
            {
                Height = { Pixels = 220f },
                Top = { Pixels = 140f },
                HAlign = 1f
            };
            mainPanel.Append(scrollbar);
            waypointList.SetScrollbar(scrollbar);

            statusText = new UIText("", 0.75f)
            {
                HAlign = 0.5f,
                Top = { Pixels = 368f }
            };
            mainPanel.Append(statusText);

            var closeButton = new UIText("[Tutup]", 0.8f)
            {
                HAlign = 0.5f,
                Top = { Pixels = 392f }
            };
            closeButton.OnLeftClick += (_, _) => WaypointUISystem.CloseUI();
            closeButton.OnMouseOver += (_, _) => closeButton.TextColor = Color.Yellow;
            closeButton.OnMouseOut += (_, _) => closeButton.TextColor = Color.White;
            mainPanel.Append(closeButton);
        }

        public void SetPortal(Point16 baseOrigin)
        {
            currentBaseOrigin = baseOrigin;

            if (!TryGetEntity(baseOrigin, out PortalWaypointEntity self))
                return;

            nameField.SetText(self.WaypointName);
            statusText.SetText("");
            RebuildList(self);
        }

        private void RebuildList(PortalWaypointEntity self)
        {
            waypointList.Clear();

            var others = WaypointSystem.All
                .Where(e => new Point16(e.Position.X, e.Position.Y) != currentBaseOrigin)
                .OrderBy(e => e.WaypointName)
                .ToList();

            if (others.Count == 0)
            {
                var empty = new UIText("Belum ada Waypoint lain.", 0.7f) { HAlign = 0.5f };
                empty.TextColor = Color.Gray;
                waypointList.Add(empty);
                return;
            }

            var localPlayer = Main.LocalPlayer.GetModPlayer<PortalPlayer>();

            foreach (var entity in others)
            {
                Point16 targetOrigin = new Point16(entity.Position.X, entity.Position.Y);
                bool isSelected = localPlayer.SelectedDestinationBaseOrigin == targetOrigin;

                var entry = new UIPanel();
                entry.SetPadding(6f);
                entry.Height.Set(38f, 0f);
                entry.Width.Set(0f, 1f);
                entry.BackgroundColor = isSelected ? new Color(120, 60, 140) : new Color(60, 40, 70);

                var label = new UIText(entity.WaypointName, 0.75f);
                entry.Append(label);

                entry.OnLeftClick += (_, _) =>
                {
                    localPlayer.SelectedDestinationBaseOrigin = targetOrigin;
                    statusText.SetText($"Estimasi diset ke: {entity.WaypointName}");
                    RebuildList(self); // refresh highlight
                };
                entry.OnMouseOver += (_, _) => entry.BackgroundColor = new Color(100, 55, 120);
                entry.OnMouseOut += (_, _) =>
                    entry.BackgroundColor = isSelected ? new Color(120, 60, 140) : new Color(60, 40, 70);

                waypointList.Add(entry);
            }
        }

        private void CommitRename()
        {
            if (!TryGetEntity(currentBaseOrigin, out PortalWaypointEntity self))
                return;

            string wanted = nameField.CurrentString;
            WaypointSystem.Rename(self, wanted);
            nameField.SetText(self.WaypointName);
            RebuildList(self);
        }

        private static bool TryGetEntity(Point16 baseOrigin, out PortalWaypointEntity entity)
        {
            foreach (var e in WaypointSystem.All)
            {
                if (new Point16(e.Position.X, e.Position.Y) == baseOrigin)
                {
                    entity = e;
                    return true;
                }
            }

            entity = null;
            return false;
        }
    }
}
