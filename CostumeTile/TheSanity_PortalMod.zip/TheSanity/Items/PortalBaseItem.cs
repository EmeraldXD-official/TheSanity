using Terraria.ID;
using Terraria.ModLoader;

namespace TheSanity.Items
{
    public class PortalBaseItem : ModItem
    {
        // Pakai langsung sprite tile-nya sebagai icon item, tidak perlu bikin PNG item terpisah.
        public override string Texture => "TheSanity/CostumeTile/PortalBase";

        public override void SetDefaults()
        {
            Item.width = 32;
            Item.height = 16;
            Item.maxStack = 999;
            Item.useTurn = true;
            Item.autoReuse = true;
            Item.useAnimation = 15;
            Item.useTime = 10;
            Item.useStyle = ItemUseStyleID.Swing;
            Item.consumable = true;
            Item.value = 500;
            Item.rare = ItemRarityID.Blue;
            Item.createTile = ModContent.TileType<Tiles.PortalBase>();
        }
    }
}
