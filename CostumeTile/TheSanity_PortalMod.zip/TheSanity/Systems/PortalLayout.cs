using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;

namespace TheSanity.Systems
{
    /// <summary>
    /// Semua ukuran & offset relatif antar tile Portal dikumpulkan di sini,
    /// biar kalau perlu di-tweak (misal PortalTop ternyata 3x2 bukan 3x1),
    /// cukup ubah di satu tempat ini saja.
    /// </summary>
    public static class PortalLayout
    {
        // PortalBase: 3 lebar x 1 tinggi, ini "lantai" / anchor utama.
        public const int BaseWidth = 3;
        public const int BaseHeight = 1;

        // Portal (background object animasi, Portal.png): 3 lebar x 3 tinggi,
        // duduk PERSIS di atas PortalBase.
        public const int PortalWidth = 3;
        public const int PortalHeight = 3;

        // PortalTop (background object, PortalTop.png): 3 lebar, anggap 1 tinggi
        // (ubah PortalTopHeight kalau sprite aslinya lebih tinggi), duduk di atas Portal.
        public const int PortalTopWidth = 3;
        public const int PortalTopHeight = 1;

        // Spritesheet Portal.png: 32x352, 8 frame -> tinggi per frame 44px
        public const int PortalFrameCount = 8;
        public const int PortalFrameHeight = 44; // 352 / 8

        // 0,1 frame per detik = ganti frame tiap 10 detik = 600 tick (60 tick/detik)
        public const int PortalAnimationTicksPerFrame = 600;

        /// <summary>
        /// Dari koordinat tile manapun yang termasuk multitile PortalBase,
        /// cari titik origin (kiri-atas) nya.
        /// </summary>
        public static Point16 GetBaseOrigin(int i, int j)
        {
            Tile tile = Main.tile[i, j];
            int column = tile.TileFrameX / 18; // 0,1,2 untuk width=3
            return new Point16(i - column, j);
        }

        /// <summary>
        /// Titik tengah dunia (world position, pixel) dari tile Portal.png (3x3)
        /// yang berdiri di atas sebuah PortalBase dengan origin tertentu.
        /// Ini titik yang harus disentuh player supaya kepicu masuk portal.
        /// </summary>
        public static Vector2 GetPortalCenterWorld(Point16 baseOrigin)
        {
            float baseLeftX = baseOrigin.X * 16f;
            float baseTopY = baseOrigin.Y * 16f;

            float centerX = baseLeftX + (BaseWidth * 16f) / 2f;
            // Portal (3x3) ada tepat di atas PortalBase
            float portalTopY = baseTopY - (PortalHeight * 16f);
            float centerY = portalTopY + (PortalHeight * 16f) / 2f;

            return new Vector2(centerX, centerY);
        }

        /// <summary>
        /// Origin (kiri-atas) tile Portal (3x3) relatif ke origin PortalBase.
        /// </summary>
        public static Point16 GetPortalOrigin(Point16 baseOrigin)
            => new Point16(baseOrigin.X, (short)(baseOrigin.Y - PortalHeight));

        /// <summary>
        /// Origin (kiri-atas) tile PortalTop relatif ke origin PortalBase.
        /// </summary>
        public static Point16 GetPortalTopOrigin(Point16 baseOrigin)
            => new Point16(baseOrigin.X, (short)(baseOrigin.Y - PortalHeight - PortalTopHeight));
    }
}
