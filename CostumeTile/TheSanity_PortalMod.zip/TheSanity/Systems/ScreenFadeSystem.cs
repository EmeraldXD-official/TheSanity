using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.GameContent;
using Terraria.ModLoader;
using TheSanity.Players;

namespace TheSanity.Systems
{
    public class ScreenFadeSystem : ModSystem
    {
        public override void PostDrawInterface(SpriteBatch spriteBatch)
        {
            if (Main.LocalPlayer == null || !Main.LocalPlayer.active)
                return;

            float alpha = Main.LocalPlayer.GetModPlayer<PortalPlayer>().FadeAlpha;
            if (alpha <= 0f)
                return;

            spriteBatch.Draw(
                TextureAssets.MagicPixel.Value,
                new Rectangle(0, 0, Main.screenWidth, Main.screenHeight),
                Color.Black * alpha);
        }
    }
}
