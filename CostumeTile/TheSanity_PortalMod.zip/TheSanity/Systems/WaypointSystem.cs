using System.Collections.Generic;
using System.Linq;
using Terraria.DataStructures;
using Terraria.ModLoader;
using TheSanity.TileEntities;

namespace TheSanity.Systems
{
    /// <summary>
    /// Registry global semua PortalWaypointEntity yang ada di dunia,
    /// dipakai UI untuk menampilkan daftar waypoint & untuk memastikan
    /// nama waypoint unik ("waypoint", "waypoint1", "waypoint2", dst).
    /// </summary>
    public class WaypointSystem : ModSystem
    {
        private static readonly Dictionary<int, PortalWaypointEntity> registry = new();

        public static void Register(PortalWaypointEntity entity)
        {
            if (entity == null) return;
            registry[entity.ID] = entity;
        }

        public static void Unregister(int id)
        {
            registry.Remove(id);
        }

        public static IReadOnlyCollection<PortalWaypointEntity> All => registry.Values;

        /// <summary>
        /// Pastikan nama baseName unik di antara semua waypoint yang sudah ada
        /// (selain excludeId, dipakai saat rename entity itu sendiri).
        /// "waypoint" -> tetap "waypoint" kalau belum dipakai.
        /// Kalau sudah dipakai -> "waypoint1", "waypoint2", dst (angka terkecil yang bebas).
        /// </summary>
        public static string GetUniqueName(string baseName, int excludeId)
        {
            baseName = string.IsNullOrWhiteSpace(baseName) ? "waypoint" : baseName.Trim();

            bool taken = registry.Values.Any(e => e.ID != excludeId && e.WaypointName == baseName);
            if (!taken)
                return baseName;

            int n = 1;
            while (registry.Values.Any(e => e.ID != excludeId && e.WaypointName == baseName + n))
                n++;

            return baseName + n;
        }

        /// <summary>
        /// Dipanggil dari UI saat player rename sebuah waypoint.
        /// </summary>
        public static void Rename(PortalWaypointEntity entity, string newBaseName)
        {
            entity.WaypointName = GetUniqueName(newBaseName, entity.ID);
        }

        public override void OnWorldLoad()
        {
            registry.Clear();
            // Daftarkan ulang semua TileEntity yang sudah ada di save file.
            foreach (var kv in TileEntity.ByID)
            {
                if (kv.Value is PortalWaypointEntity pwe)
                    registry[pwe.ID] = pwe;
            }
        }

        public override void OnWorldUnload()
        {
            registry.Clear();
        }
    }
}
