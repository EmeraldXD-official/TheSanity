using Terraria.Audio;

namespace TheSanity
{
    public static class Sounds
    {
        // File aslinya: ModSources/TheSanity/Sounds/EnterPortal.mp3
        // (tModLoader meng-autoload berdasarkan path relatif terhadap folder mod, tanpa ekstensi)
        public static readonly SoundStyle EnterPortal = new("TheSanity/Sounds/EnterPortal");
    }
}
