using System.IO;
using Terraria;
using Terraria.DataStructures;
using Terraria.ModLoader;
using Terraria.ModLoader.IO;
using TheSanity.Systems;
using TheSanity.Tiles;

namespace TheSanity.TileEntities
{
    /// <summary>
    /// Satu instance per PortalBase yang ditancapkan di dunia.
    /// Menyimpan nama Waypoint-nya, dan mendaftar ke WaypointSystem
    /// supaya bisa muncul di UI pemilihan.
    /// </summary>
    public class PortalWaypointEntity : ModTileEntity
    {
        public string WaypointName = "waypoint";

        public override bool IsTileValidForEntity(int x, int y)
        {
            Tile tile = Main.tile[x, y];
            return tile.HasTile && tile.TileType == ModContent.TileType<PortalBase>();
        }

        public override int Hook_AfterPlacement(int i, int j, int type, int style, int direction, int alternate = 0)
        {
            Point16 origin = PortalLayout.GetBaseOrigin(i, j);

            if (!WorldGen.InWorld(origin.X, origin.Y))
                return -1;

            int existingId = Place(origin.X, origin.Y);

            if (Main.tile[origin.X, origin.Y].TileType == type &&
                ModTileEntity.ByPosition.TryGetValue(origin, out TileEntity te) &&
                te is PortalWaypointEntity entity)
            {
                entity.WaypointName = WaypointSystem.GetUniqueName("waypoint", entity.ID);
                WaypointSystem.Register(entity);
            }

            if (Main.netMode == Terraria.ID.NetmodeID.MultiplayerClient)
                NetMessage.SendTileSquare(-1, origin.X, origin.Y, BaseWidth, BaseHeight());

            return existingId;
        }

        private static int BaseHeight() => Systems.PortalLayout.BaseHeight;
        private static int BaseWidth => Systems.PortalLayout.BaseWidth;

        public override void OnKill()
        {
            WaypointSystem.Unregister(ID);
        }

        public override void SaveData(TagCompound tag)
        {
            tag["waypointName"] = WaypointName;
        }

        public override void LoadData(TagCompound tag)
        {
            WaypointName = tag.GetString("waypointName");
            if (string.IsNullOrWhiteSpace(WaypointName))
                WaypointName = "waypoint";
        }
    }
}
