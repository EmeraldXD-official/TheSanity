using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Audio;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using TheSanity.Buffs;
using TheSanity.Systems;

namespace TheSanity.Players
{
    public class PortalPlayer : ModPlayer
    {
        private enum Phase
        {
            None,
            FadingOut,   // 1 detik, buff Obstructed aktif, partikel muncul
            Locked,      // saat titik hitam penuh, teleport dieksekusi di sini
            FadingIn     // layar perlahan kembali normal, player masih invincible+immobile
        }

        // Estimasi portal tujuan yang dipilih player lewat UI. Reset ke null tiap kali
        // sebuah proses teleport selesai dieksekusi.
        public Point16? SelectedDestinationBaseOrigin;

        // Origin PortalBase tempat player TERAKHIR muncul, dipakai supaya tidak
        // langsung ke-trigger ulang selama masih berdiri di dekat portal itu.
        private Point16? arrivedAtBaseOrigin;

        private Phase phase = Phase.None;
        private int timer;
        private Point16 travelFromOrigin;
        private Point16 travelToOrigin;

        public float FadeAlpha; // 0 = normal, 1 = hitam total. Dibaca oleh ScreenFadeSystem untuk digambar.

        private const int FadeOutTicks = 60;   // 1 detik -> durasi Obstructed juga 1 detik
        private const int LockTicks = 8;       // jeda singkat pas hitam penuh sebelum reveal
        private const int FadeInTicks = 45;
        private const int PostArrivalImmuneTicks = 40; // invincible + tak bisa apa-apa sesaat setelah nongol

        public override void ResetEffects()
        {
            // tidak ada reset per-tick khusus, semua di-drive lewat phase state machine
        }

        public override void PreUpdateMovement()
        {
            if (phase != Phase.None)
            {
                // Kunci total pergerakan selama proses berlangsung.
                Player.velocity = Vector2.Zero;
                Player.controlLeft = Player.controlRight = false;
                Player.controlUp = Player.controlDown = false;
                Player.controlJump = false;
                Player.controlUseItem = false;
                Player.controlUseTile = false;
            }
        }

        public override void PostUpdate()
        {
            // Kalau player sudah menjauh >= 3 block dari PortalBase tempat dia terakhir
            // muncul, "kunci anti re-trigger" dilepas supaya portal itu bisa dipakai lagi.
            if (arrivedAtBaseOrigin.HasValue)
            {
                Vector2 baseCenter = new Vector2(
                    arrivedAtBaseOrigin.Value.X * 16f + 24f,
                    arrivedAtBaseOrigin.Value.Y * 16f + 8f);

                float distanceInTiles = Vector2.Distance(Player.Center, baseCenter) / 16f;
                if (distanceInTiles >= 3f)
                    arrivedAtBaseOrigin = null;
            }

            switch (phase)
            {
                case Phase.None:
                    TryDetectPortalTouch();
                    break;

                case Phase.FadingOut:
                    timer++;
                    FadeAlpha = MathHelper.Clamp(timer / (float)FadeOutTicks, 0f, 1f);
                    SpawnTravelDust();

                    if (timer >= FadeOutTicks)
                    {
                        phase = Phase.Locked;
                        timer = 0;
                        ExecuteTeleport();
                    }
                    break;

                case Phase.Locked:
                    timer++;
                    FadeAlpha = 1f;
                    if (timer >= LockTicks)
                    {
                        phase = Phase.FadingIn;
                        timer = 0;
                    }
                    break;

                case Phase.FadingIn:
                    timer++;
                    FadeAlpha = MathHelper.Clamp(1f - timer / (float)FadeInTicks, 0f, 1f);
                    Player.immune = true;
                    Player.immuneNoBlink = true;

                    if (timer >= FadeInTicks)
                    {
                        phase = Phase.None;
                        timer = 0;
                        FadeAlpha = 0f;
                    }
                    break;
            }
        }

        private void TryDetectPortalTouch()
        {
            if (!SelectedDestinationBaseOrigin.HasValue)
                return; // belum pilih estimasi -> tidak terjadi apa-apa

            foreach (var entity in WaypointSystem.All)
            {
                Point16 baseOrigin = new Point16(entity.Position.X, entity.Position.Y);

                // Jangan izinkan trigger ulang di portal yang barusan jadi tempat kemunculan.
                if (arrivedAtBaseOrigin.HasValue && arrivedAtBaseOrigin.Value == baseOrigin)
                    continue;

                Vector2 portalCenter = PortalLayout.GetPortalCenterWorld(baseOrigin);

                // Radius sentuh kira-kira setengah tile ke segala arah dari titik tengah Portal.png
                float touchRadius = 20f;
                if (Vector2.Distance(Player.Center, portalCenter) <= touchRadius)
                {
                    BeginTeleport(baseOrigin, SelectedDestinationBaseOrigin.Value);
                    break;
                }
            }
        }

        private void BeginTeleport(Point16 from, Point16 to)
        {
            if (from == to)
                return; // jangan biarkan teleport ke portal yang sama persis

            travelFromOrigin = from;
            travelToOrigin = to;
            phase = Phase.FadingOut;
            timer = 0;
            FadeAlpha = 0f;

            Player.AddBuff(ModContent.BuffType<ObstructedBuff>(), FadeOutTicks + 5);
        }

        private void ExecuteTeleport()
        {
            Vector2 destinationCenter = PortalLayout.GetPortalCenterWorld(travelToOrigin);
            // Muncul persis di tengah sprite Portal.png tujuan.
            Player.Teleport(destinationCenter, TeleportationStyleID.RodOfDiscord);

            SoundEngine.PlaySound(TheSanity.Sounds.EnterPortal, Player.Center);

            arrivedAtBaseOrigin = travelToOrigin;

            // Reset estimasi -> player wajib pilih lagi untuk lompat berikutnya.
            SelectedDestinationBaseOrigin = null;

            Player.immune = true;
            Player.immuneNoBlink = true;
            Player.immuneTime = System.Math.Max(Player.immuneTime, PostArrivalImmuneTicks);
        }

        private void SpawnTravelDust()
        {
            if (Main.rand.NextBool(2))
            {
                Vector2 offset = Main.rand.NextVector2CircularEdge(28f, 28f);
                int dustType = Main.rand.NextBool() ? DustID.PinkFairy : DustID.Torch;
                Dust d = Dust.NewDustPerfect(Player.Center + offset, dustType,
                    (Player.Center - (Player.Center + offset)) * 0.02f);
                d.noGravity = true;
                d.scale = 1.3f;
            }
        }

        public bool IsBusy => phase != Phase.None;
    }
}
