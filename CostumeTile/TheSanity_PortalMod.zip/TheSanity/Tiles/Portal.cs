using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.ObjectData;
using TheSanity.Systems;

namespace TheSanity.Tiles
{
    /// <summary>
    /// Background object non-solid, 3x3, memakai spritesheet Portal.png (32x352, 8 frame).
    /// Ini bagian yang harus disentuh player di tengah-tengahnya untuk memicu teleport
    /// (logikanya ada di Players/PortalPlayer.cs).
    /// </summary>
    public class Portal : ModTile
    {
        public override void SetStaticDefaults()
        {
            Main.tileSolid[Type] = false;
            Main.tileNoAttach[Type] = true;
            Main.tileFrameImportant[Type] = true;
            Main.tileLighted[Type] = true; // portal menyala sendiri
            Main.tileObsidianKill[Type] = false;

            TileObjectData.newTile.CopyFrom(TileObjectData.Style3x3);
            TileObjectData.newTile.Width = PortalLayout.PortalWidth;
            TileObjectData.newTile.Height = PortalLayout.PortalHeight;
            TileObjectData.newTile.Origin = new Point16(0, 0);
            TileObjectData.newTile.CoordinateHeights = new[] { 16, 16, 16 };
            TileObjectData.newTile.CoordinateWidth = 16;
            TileObjectData.newTile.CoordinatePadding = 2;
            TileObjectData.newTile.UsesCustomCanPlace = true;
            TileObjectData.newTile.LavaDeath = false;
            TileObjectData.newTile.AnchorInvalidTiles = new int[0];
            TileObjectData.addTile(Type);

            // Tile ini TIDAK dijual/ditancapkan sendiri lewat item — selalu dibangun
            // otomatis oleh PortalBase.PlaceInWorld().
            AddMapEntry(new Color(200, 100, 220), CreateMapEntryName());

            AnimationFrameHeight = PortalLayout.PortalFrameHeight;
        }

        public override void AnimateTile(ref int frame, ref int frameCounter)
        {
            frameCounter++;
            if (frameCounter >= PortalLayout.PortalAnimationTicksPerFrame)
            {
                frameCounter = 0;
                frame = (frame + 1) % PortalLayout.PortalFrameCount;
            }
        }

        // Non-solid & tidak bisa "ditumbangkan" satuan — hanya ikut hancur lewat PortalBase.
        public override bool CanExplode(int i, int j) => false;

        public override bool CanKillTile(int i, int j, ref bool blockDamaged) => true;
    }
}
