using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.ObjectData;
using TheSanity.Systems;
using TheSanity.TileEntities;
using TheSanity.UI;

namespace TheSanity.Tiles
{
    public class PortalBase : ModTile
    {
        public override void SetStaticDefaults()
        {
            Main.tileSolid[Type] = true;
            Main.tileFrameImportant[Type] = true;
            Main.tileNoAttach[Type] = true;
            Main.tileBlockLight[Type] = true;

            TileObjectData.newTile.CopyFrom(TileObjectData.Style1x1);
            TileObjectData.newTile.Width = PortalLayout.BaseWidth;   // 3
            TileObjectData.newTile.Height = PortalLayout.BaseHeight; // 1
            TileObjectData.newTile.Origin = new Point16(0, 0);
            TileObjectData.newTile.CoordinateHeights = new[] { 16 };
            TileObjectData.newTile.CoordinateWidth = 16;
            TileObjectData.newTile.CoordinatePadding = 2;
            TileObjectData.newTile.StyleHorizontal = true;
            TileObjectData.newTile.HookPostPlaceMyPlayer =
                new PlacementHook(PortalWaypointEntityHook, -1, 0, true);
            TileObjectData.addTile(Type);

            DustType = DustID.Stone;
            AddMapEntry(new Color(150, 90, 200), CreateMapEntryName());
        }

        // Dipanggil tModLoader otomatis begitu multitile PortalBase selesai ditancapkan.
        private static int PortalWaypointEntityHook(int i, int j, int type, int style, int direction, int normal, int random)
        {
            return ModContent.GetInstance<PortalWaypointEntity>().Hook_AfterPlacement(i, j, type, style, direction);
        }

        public override void MouseOver(int i, int j)
        {
            Player player = Main.LocalPlayer;
            player.noThrow = 2;
            player.cursorItemIconEnabled = true;
            player.cursorItemIconID = ModContent.ItemType<Items.PortalBaseItem>();
        }

        public override bool RightClick(int i, int j)
        {
            Point16 origin = PortalLayout.GetBaseOrigin(i, j);
            WaypointUISystem.OpenForPortal(origin);
            return true;
        }

        public override void PlaceInWorld(int i, int j, Item item)
        {
            Point16 origin = PortalLayout.GetBaseOrigin(i, j);

            // Sisi pojok (kolom pertama & terakhir dari 3 lebar) dijadikan "setengah blok"
            // ala tangga, memakai mekanisme half-brick vanilla.
            WorldGen.PoundTile(origin.X, origin.Y);
            WorldGen.PoundTile(origin.X + PortalLayout.BaseWidth - 1, origin.Y);

            // Bangun Portal (3x3 animasi) & PortalTop di atas PortalBase secara otomatis.
            Point16 portalOrigin = PortalLayout.GetPortalOrigin(origin);
            Point16 topOrigin = PortalLayout.GetPortalTopOrigin(origin);

            int portalType = ModContent.TileType<Portal>();
            int topType = ModContent.TileType<PortalTop>();

            if (!Main.tile[portalOrigin.X, portalOrigin.Y].HasTile ||
                Main.tile[portalOrigin.X, portalOrigin.Y].TileType != portalType)
            {
                WorldGen.PlaceTile(portalOrigin.X, portalOrigin.Y, portalType, mute: true, forced: true);
            }

            if (!Main.tile[topOrigin.X, topOrigin.Y].HasTile ||
                Main.tile[topOrigin.X, topOrigin.Y].TileType != topType)
            {
                WorldGen.PlaceTile(topOrigin.X, topOrigin.Y, topType, mute: true, forced: true);
            }
        }

        public override void KillMultiTile(int i, int j, int frameX, int frameY, int type)
        {
            Point16 origin = new Point16(i, j);

            // Ikut hancurkan Portal & PortalTop yang menempel di atasnya.
            Point16 portalOrigin = PortalLayout.GetPortalOrigin(origin);
            Point16 topOrigin = PortalLayout.GetPortalTopOrigin(origin);

            if (Main.tile[portalOrigin.X, portalOrigin.Y].HasTile)
                WorldGen.KillTile(portalOrigin.X, portalOrigin.Y, noItem: true);

            if (Main.tile[topOrigin.X, topOrigin.Y].HasTile)
                WorldGen.KillTile(topOrigin.X, topOrigin.Y, noItem: true);
        }

        public override void NumDust(int i, int j, bool fail, ref int num) => num = fail ? 1 : 3;

        public override bool CanExplode(int i, int j) => false;
    }
}
