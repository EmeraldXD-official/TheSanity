using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ModLoader;
using Terraria.ObjectData;
using TheSanity.Systems;

namespace TheSanity.Tiles
{
    /// <summary>
    /// Background object dekoratif murni (tidak ada logika interaksi), dari PortalTop.png,
    /// duduk di atas tile Portal. Ukuran default 3 lebar x 1 tinggi — sesuaikan
    /// PortalLayout.PortalTopHeight kalau sprite aslinya berbeda.
    /// </summary>
    public class PortalTop : ModTile
    {
        public override void SetStaticDefaults()
        {
            Main.tileSolid[Type] = false;
            Main.tileNoAttach[Type] = true;
            Main.tileFrameImportant[Type] = true;
            Main.tileLighted[Type] = true;

            TileObjectData.newTile.CopyFrom(TileObjectData.Style1x1);
            TileObjectData.newTile.Width = PortalLayout.PortalTopWidth;
            TileObjectData.newTile.Height = PortalLayout.PortalTopHeight;
            TileObjectData.newTile.Origin = new Point16(0, 0);
            TileObjectData.newTile.CoordinateHeights = new[] { 16 };
            TileObjectData.newTile.CoordinateWidth = 16;
            TileObjectData.newTile.CoordinatePadding = 2;
            TileObjectData.newTile.StyleHorizontal = true;
            TileObjectData.addTile(Type);

            AddMapEntry(new Color(200, 100, 220), CreateMapEntryName());
        }

        public override bool CanExplode(int i, int j) => false;
    }
}
