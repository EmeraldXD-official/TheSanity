using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ModLoader;

namespace TheSanity.Buffs
{
    /// <summary>
    /// Debuff kosmetik/fungsional yang dipasang selama fase "layar menghitam"
    /// sebelum player benar-benar berpindah portal. Mengunci semua kontrol.
    /// </summary>
    public class ObstructedBuff : ModBuff
    {
        public override void SetStaticDefaults()
        {
            Main.debuff[Type] = true;
            Main.buffNoSave[Type] = true;
            Main.pvpBuff[Type] = false;
        }

        public override void Update(Player player, ref int buffIndex)
        {
            player.velocity = Vector2.Zero;
            player.controlLeft = false;
            player.controlRight = false;
            player.controlUp = false;
            player.controlDown = false;
            player.controlJump = false;
            player.controlUseItem = false;
            player.controlUseTile = false;
            player.controlHook = false;
            player.controlMount = false;
            player.controlThrow = false;
            player.immune = true;
            player.immuneNoBlink = true;
        }
    }
}
