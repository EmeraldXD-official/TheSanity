# Sistem Portal "TheSanity" — Panduan Pasang & Catatan Penting

## 1. Cara pasang

1. Extract folder `TheSanity/` ini (Tiles, Items, TileEntities, Systems, UI, Buffs, Players, Sounds.cs)
   ke dalam `ModSources/TheSanity/`, **timpa/gabung** dengan struktur project kamu yang sudah ada.
2. Pastikan sprite kamu ada di:
   - `TheSanity/CostumeTile/PortalBase.png`
   - `TheSanity/CostumeTile/Portal.png`
   - `TheSanity/CostumeTile/PortalTop.png`
   - `TheSanity/Sounds/EnterPortal.mp3`
   (sesuai lokasi yang kamu sebutkan — namespace path di kode sudah disesuaikan dengan ini)
3. **PENTING**: `ObstructedBuff` butuh icon `TheSanity/Buffs/ObstructedBuff.png` (32x32).
   Kalau belum ada, mod akan gagal build karena auto-texture-loading. Buat PNG placeholder dulu kalau perlu.
4. Build & reload mod seperti biasa (`tModLoader.exe` -> Build -> Reload Mods, atau lewat
   Steam dev environment kamu).

## 2. Ringkasan fitur yang sudah diimplementasikan

- **PortalBase** (item + tile 3x1): waktu ditancapkan, otomatis membangun `Portal` (3x3,
  animasi) dan `PortalTop` di atasnya, lalu daftar sebagai Waypoint baru bernama `waypoint`
  (atau `waypoint1`, `waypoint2`, dst kalau nama sudah dipakai).
- Kolom kiri & kanan dari PortalBase otomatis dijadikan **half-brick** (`WorldGen.PoundTile`)
  supaya kelihatan seperti tangga di pojoknya.
- **Right-click** PortalBase -> buka UI **Waypoint**: rename nama portal ini, dan pilih
  salah satu Waypoint lain sebagai **estimasi tujuan** (per-player, tersimpan di `PortalPlayer`).
- Kalau player sudah pilih estimasi lalu **menyentuh titik tengah sprite Portal.png**:
  1. Kontrol player dikunci total (gerak, pakai item, dsb).
  2. Debuff **Obstructed** terpasang 1 detik.
  3. Layar perlahan menghitam + partikel pink/oranye muncul di sekitar player.
  4. Setelah hitam penuh -> player di-teleport ke tengah Portal.png tujuan, suara
     `EnterPortal.mp3` diputar.
  5. Player invincible + masih tidak bisa berbuat apa-apa sesaat, layar perlahan terang lagi.
  6. Estimasi tujuan **direset ke kosong** — wajib pilih ulang untuk lompat berikutnya.
- Anti-spam: begitu nongol di portal tujuan, portal itu **tidak akan trigger lagi** sampai
  player menjauh >= 3 block dari PortalBase-nya, baru bisa dipakai lagi (dan hanya kalau
  sudah pilih estimasi baru).
- Animasi `Portal.png`: 8 frame, ganti frame tiap 10 detik (0.1 frame/detik) — konstanta ada
  di `Systems/PortalLayout.cs` kalau mau diubah.

## 3. Bagian yang paling mungkin perlu kamu sesuaikan (saya tidak bisa compile-test di sini)

- **`PortalLayout.PortalTopHeight`** saya asumsikan 1 tile. Kalau sprite `PortalTop.png`
  aslinya lebih tinggi dari 1 block, ubah nilai ini (dan cek ulang penempatan offset-nya).
- **Titik "tengah" Portal.png untuk trigger teleport** dihitung otomatis dari ukuran 3x3 di
  `PortalLayout.GetPortalCenterWorld`. Kalau secara visual titik tengahnya meleset dikit
  (karena sprite 32px lebar vs grid 48px), tinggal geser offset X/Y di fungsi itu.
- **Icon item `PortalBaseItem`** saat ini memakai sprite tile `PortalBase.png` langsung
  sebagai icon di inventory. Kalau bentuknya aneh di slot inventory (karena tile-nya lebar 3
  block), sebaiknya buat sprite item terpisah (mis. `Items/PortalBaseItem.png`) dan hapus
  override `Texture` di `PortalBaseItem.cs`.
- **Warna & jenis Dust** partikel pakai `DustID.PinkFairy` dan `DustID.Torch` sebagai
  pendekatan "pink & orange". Ganti ke Dust ID lain di `PortalPlayer.SpawnTravelDust()`
  kalau warnanya kurang pas.
- **Durasi-durasi** (`FadeOutTicks`, `LockTicks`, `FadeInTicks`, `PostArrivalImmuneTicks`)
  ada di atas `PortalPlayer.cs`, gampang di-tweak.
- **Multiplayer**: implementasi ini fokus dulu ke logika single-player-correct (estimasi &
  state disimpan per-`ModPlayer`, tile entity sudah tersinkron standar tModLoader). Untuk
  MP yang benar-benar rapi (misalnya biar client lain lihat efek teleport client lain),
  idealnya ditambah `ModPacket` untuk broadcast momen mulai/selesai teleport — belum saya
  buatkan karena butuh testing langsung di server.
- **`RightClick`** saat ini tidak mengecek apakah player sedang dalam kondisi lain yang
  harusnya memblokir buka UI (misal sedang buka chest lain). Tambahkan pengecekan kalau perlu.

## 4. Struktur file yang dibuat

```
TheSanity/
  Sounds.cs
  Tiles/PortalBase.cs
  Tiles/Portal.cs
  Tiles/PortalTop.cs
  Items/PortalBaseItem.cs
  TileEntities/PortalWaypointEntity.cs
  Systems/PortalLayout.cs
  Systems/WaypointSystem.cs
  Systems/ScreenFadeSystem.cs
  Buffs/ObstructedBuff.cs
  Players/PortalPlayer.cs
  UI/WaypointUIState.cs
  UI/WaypointUISystem.cs
```

## 5. Kalau nanti ada error compile

Kirim aja pesan error-nya ke aku (copy full text-nya), biasanya cukup dari nama method/field
yang mismatch dengan versi tModLoader kamu — saya tulis kode ini berdasarkan API 1.4.4 yang
saya tahu, tapi beberapa signature kecil (terutama di `UIInputTextField`, `TileObjectData`
hook parameter) bisa saja sedikit beda tergantung versi patch tModLoader kamu.
